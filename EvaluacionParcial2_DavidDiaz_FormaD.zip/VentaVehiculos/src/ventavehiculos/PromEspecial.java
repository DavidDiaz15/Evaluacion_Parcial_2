/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ventavehiculos;

/**
 *
 * @author Duoc
 */
public interface PromEspecial {
    double DTO = 0.123;
    
    //Metodo abstracto
    double descuentoFeriado ();
}
