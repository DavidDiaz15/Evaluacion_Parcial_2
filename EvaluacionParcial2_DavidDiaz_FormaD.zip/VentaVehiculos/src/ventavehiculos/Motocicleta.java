/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ventavehiculos;

/**
 *
 * @author Duoc
 */
public class Motocicleta extends Vehiculo {
    //Atributos
    private String tipo;
    private int cilindrada;
    
    //Constructores
    public Motocicleta(String tipo, int cilindrada, String codigo, String marca, String modelo, double precioBase, int anioFabricacion) {
        super(codigo, marca, modelo, precioBase, anioFabricacion);
        this.tipo = tipo;
        this.cilindrada = cilindrada;
    }

    public Motocicleta(String tipo, int cilindrada) {
        this.tipo = tipo;
        this.cilindrada = cilindrada;
    }
    
    //Gett y sett
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }
    
    //Metodos

    @Override
    public boolean ajustePrecio() {
        if (this.tipo.equalsIgnoreCase("Clasica")){
            this.precioBase = this.precioBase * (1 - 0.15);
            return true;
        }
        return false;
    }

    @Override
    public boolean aplicarImpuesto() {
        if (this.cilindrada > 600){
           this.precioBase = this.precioBase * (1 + 0.10);
           return true;
        }
        return false;
    }

    @Override
    public double descuentoFeriado() {
        return 0;
    }
    
    @Override
    public void informacion() {
        System.out.println("--- MOTOCICLETA ---");
        System.out.println("Codigo: " + getCodigo());
        System.out.println("Marca: " + getMarca());
        System.out.println("Modelo: " + getModelo());
        System.out.println("Anio Fabricacion: " + getAnioFabricacion());
        System.out.println("Tipo de Moto: " + getTipo());
        System.out.println("Cilindrada (cc): " + getCilindrada());
        System.out.println("Precio base: " + getPrecioBase());
        System.out.println("");
    }   
}