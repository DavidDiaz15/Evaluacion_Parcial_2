/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ventavehiculos;
import java.util.ArrayList;

/**
 *
 * @author Duoc
 */
public class Concesionaria {
    private ArrayList<Vehiculo> gestionVehiculos;
    
    public Concesionaria(){
        gestionVehiculos = new ArrayList<>();
    }
    
    //Constructores
    public Concesionaria(ArrayList<Vehiculo> gestionVehiculos) {
        this.gestionVehiculos = gestionVehiculos;
    }
    
    //Metodos
    //Ingresar vehiculo
    public boolean ingresarVehiculo(Vehiculo v){
        for (Vehiculo existente: gestionVehiculos){
            if (existente.getCodigo().equalsIgnoreCase(v.getCodigo())){
                System.out.print("YA EXISTE ESTE VEHICULO (AUTO O MOTO), INGRESE UNO CON UN CODIGO DIFERENTE");
                return false;
            }
        }
        gestionVehiculos.add(v);
        return true;
    }
    
    //Buscar vehiculo
    public Vehiculo buscarVehiculo(String codigo){
        for (Vehiculo v : this.gestionVehiculos){
            if (v.getCodigo().equalsIgnoreCase(codigo)){
                return v;
            }
        }
        return null;
    }
    
    //Aplicar ajuste a todos
    public int aplicarAjusteATodo() {
        int ajustes = 0;
        for (Vehiculo v : gestionVehiculos){
            if (v.ajustePrecio()) {
                ajustes = ajustes + 1;
            }
        }
        return ajustes;
    }
    
    //Aplicar los impuestos or suv y cilindrada
    public int aplicarImpuestoATodos() {
        int impu = 0;
        for (Vehiculo v : gestionVehiculos) {
            if (v.aplicarImpuesto()) {
                impu = impu + 1;
            }
        }
        return impu;
    }
    
    //calcular descuento ahorrado
    public double calcularDescuentoTotal() {
        double totalDcto = 0;
        for (Vehiculo v : gestionVehiculos) {
            totalDcto = totalDcto + v.descuentoFeriado();
        }
        return totalDcto;
    }
    
}
