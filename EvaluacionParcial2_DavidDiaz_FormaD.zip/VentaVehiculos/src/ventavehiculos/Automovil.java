/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ventavehiculos;

/**
 *
 * @author Duoc
 */
public class Automovil extends Vehiculo {
    //Atributos
    private String tipoCarroceria;
    private int cantidadPuertas;
    
    //Constructores
    public Automovil(String tipoCarroceria, int cantidadPuertas, String codigo, String marca, String modelo, double precioBase, int anioFabricacion) {
        super(codigo, marca, modelo, precioBase, anioFabricacion);
        this.tipoCarroceria = tipoCarroceria;
        this.cantidadPuertas = cantidadPuertas;
    }

    public Automovil(String tipoCarroceria, int cantidadPuertas) {
        this.tipoCarroceria = tipoCarroceria;
        this.cantidadPuertas = cantidadPuertas;
    }
    
    //Gett y sett}
    public String getTipoCarroceria() {
        return tipoCarroceria;
    }

    public void setTipoCarroceria(String tipoCarroceria) {
        this.tipoCarroceria = tipoCarroceria;
    }

    public int getCantidadPuertas() {
        return cantidadPuertas;
    }

    public void setCantidadPuertas(int cantidadPuertas) {
        this.cantidadPuertas = cantidadPuertas;
    }
    
    //Metodos
    @Override
    public boolean ajustePrecio() {
        return false;
    }
    
    @Override
    public boolean aplicarImpuesto() {
        if (tipoCarroceria.equalsIgnoreCase("SUV")){
            this.precioBase = this.precioBase * (1 + 0.10); //Decidi usar un impuesto de un 10% para las SUV y las cilindradas
            return true;
        }
        return false;
    }

    @Override
    public double descuentoFeriado() {
        if (tipoCarroceria.equalsIgnoreCase("SUV") && marca.equalsIgnoreCase("Ford")){
            double dcto = this.precioBase * DTO;
            this.precioBase = this.precioBase - DTO;
            return dcto;
        }
        return 0;
    }
    
    @Override
    public void informacion() {
        System.out.println("--- AUTOMOVIL ---");
        System.out.println("Codigo: " + getCodigo());
        System.out.println("Marca: " + getMarca());
        System.out.println("Modelo: " + getModelo());
        System.out.println("Anio Fabricacion: " + getAnioFabricacion());
        System.out.println("Tipo Carroceria: " + getTipoCarroceria());
        System.out.println("Cantidad de Puertas: " + getCantidadPuertas());
        System.out.println("Precio base: " + getPrecioBase());
        System.out.println("");
    }
 
}
