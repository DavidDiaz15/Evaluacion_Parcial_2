/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ventavehiculos;
import java.util.Scanner;

/**
 *
 * @author Duoc
 */
public class VentaVehiculos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        Concesionaria concesionaria = new Concesionaria();
        int opcion;
        
        do{
            System.out.println("--- LA TUERCA LOCA ---");
            System.out.println("1. Ingresar Vehiculo"); 
            System.out.println("2. Mostrar Informacion");
            System.out.println("3. Aplicar Ajuste de Precio");
            System.out.println("4. Aplicar Impuesto");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            
            opcion = sc.nextInt();
            sc.nextLine();
            
            switch (opcion){
                case 1:
                    System.out.println("--- INGRESAR NUEVO VEHICULO ---");
                    System.out.println("*** TIPO ***");
                    System.out.println("1) Automovil");
                    System.out.println("2) Motocicleta");
                    System.out.print("Seleccione una opcion: ");
                    int tipo = sc.nextInt();
                    sc.nextLine();
                    
                    if (tipo != 1 && tipo != 2){
                        System.out.println("ERROR: INGRESO NO VALIDO.");
                        
                    }else{
                        System.out.print("Codigo: ");
                        String codigo = sc.nextLine();
                        System.out.print("Marca: ");
                        String marca = sc.nextLine();
                        System.out.print("Modelo: ");
                        String modelo = sc.nextLine();
                        System.out.print("Precio Base: ");
                        double precioBase = Double.parseDouble(sc.nextLine());
                        System.out.print("Anio Fabricacion: ");
                        int anioFabricacion = sc.nextInt();
                        sc.nextLine();
                        
                        if (tipo == 1){
                            System.out.print("Tipo de carroceria (Sedan o SUV): ");
                            String tipoCarroceria = sc.nextLine();
                            System.out.print("Cantidad de puertas: ");
                            int cantidadPuertas = sc.nextInt();

                            Automovil auto1 = new Automovil(tipoCarroceria, cantidadPuertas, codigo, marca, modelo, precioBase, anioFabricacion);
                            
                            if (concesionaria.ingresarVehiculo(auto1)){
                                System.out.println("Felicidades! Vehiculo agregado con exito!");
                            } else {
                                System.out.println("Error: El codigo " + codigo + " ya existe!.");
                            }
                        } else if (tipo == 2){
                            System.out.print("Tipo de motocicleta (Deportiva o clasica): ");
                            String tipoDeMoto = sc.nextLine();
                            System.out.print("Cilindrada: ");
                            int cilindrada = sc.nextInt();
                            sc.nextLine();
                            //String tipo, int cilindrada, String codigo, String marca, String modelo, double precioBase, int anioFabricacion    
                            Motocicleta moto1 = new Motocicleta(tipoDeMoto, cilindrada, codigo, marca, modelo, precioBase, anioFabricacion);

                            if (concesionaria.ingresarVehiculo(moto1)){
                                System.out.println("Vehiculo agregado con exito!");
                            } else {
                                System.out.println("Error: El codigo " + codigo + " ya existe!." );
                            }
                        }     
                    }
                    break;
                    
                case 2:
                    System.out.println("--- Mostrar Informacion ---");
                    System.out.print("Ingrese el codigo del vehiculo: ");
                    String codigo = sc.nextLine();

                    Vehiculo v = concesionaria.buscarVehiculo(codigo);

                    if (v != null) {
                        v.informacion();
                    } else {
                        System.out.println("Error: No se encontro el codigo: '" + codigo + "'.");
                    }
                    break;
                    
                case 3:
                    int total = concesionaria.aplicarAjusteATodo();
                    System.out.println("Se ha aplicado el ajuste de forma exitosa a: "+ total + " vehiculos!");
                    break;
                    
                case 4:
                    int totalDeLosImpuestos = concesionaria.aplicarImpuestoATodos();
                    System.out.println("Se aplico impuesto del 10 porciento a: " + totalDeLosImpuestos + " vehiculos.");
                    
                    double descuento = concesionaria.calcularDescuentoTotal();
                    System.out.println("El descuento total en terminos de feriado es: " + descuento);
                    break;
                
                case 5:
                    System.out.println("Saliendo del sistema!");
                    break;
            }
            
        } while (opcion != 5);
    }
}