/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ventavehiculos;

/**
 *
 * @author Duoc
 */
public abstract class Vehiculo implements PromEspecial{
    //Atributos
    protected String codigo;
    protected String marca;
    protected String modelo;
    protected double precioBase;
    protected int anioFabricacion;
    
    //Constructores
    public Vehiculo(String codigo, String marca, String modelo, double precioBase, int anioFabricacion) {
        this.codigo = codigo;
        this.marca = marca;
        this.modelo = modelo;
        this.precioBase = precioBase;
        this.anioFabricacion = anioFabricacion;
    }

    public Vehiculo() {
    }
    
    //Gett y sett
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public void setAnioFabricacion(int anioFabricacion) {
        this.anioFabricacion = anioFabricacion;
    }
    
    //Metodos
    //Abstracto
    public abstract boolean ajustePrecio();
    
    public abstract boolean aplicarImpuesto();
    
    public abstract void informacion();
    
    @Override
    public abstract double descuentoFeriado();
    
    
}
